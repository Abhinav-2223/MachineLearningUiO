This IPython notebook additionweek42.ipynb does not require any additional
programs.
